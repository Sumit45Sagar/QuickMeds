import { Link, useParams } from "react-router-dom";
import { useGetProductsQuery } from "../redux/api/productApiSlice";
import Loader from "../components/Loader";
import Message from "../components/Message";
import Header from "../components/Header";
import Product from "./Products/Product";

const Home = () => {
  const { keyword } = useParams();
  const { data, isLoading, isError } = useGetProductsQuery({ keyword });

  return (
    <>
      {!keyword && <Header />}

      {isLoading ? (
        <Loader />
      ) : isError ? (
        <Message variant="danger">
          {isError?.data?.message || isError.error}
        </Message>
      ) : (
        <>
          {/* Hero Banner */}
          <section className="bg-gradient-to-r from-teal-100 to-blue-100 py-20 px-10">
            <div className="container mx-auto text-center">
              <h1 className="text-5xl font-bold text-teal-800 mb-4">
                Your Trusted Online Medical Store
              </h1>
              <p className="text-lg text-teal-700 mb-6">
                Explore a wide range of certified medicines at your fingertips.
              </p>
              <Link
                to="/shop"
                className="bg-teal-600 text-white py-3 px-8 rounded-full font-semibold hover:bg-teal-700"
              >
                Start Shopping
              </Link>
            </div>
          </section>

          {/* Products Section */}
          <section className="mt-16">
            <h2 className="text-3xl font-bold text-center text-teal-800 flex items-center justify-center gap-2">
              <span>🩺</span> Special Products
            </h2>

            <div className="flex flex-wrap justify-center gap-10 mt-10 px-4">
              {data.products.map((product) => (
                <Product key={product._id} product={product} />
              ))}
            </div>
          </section>
        </>
      )}
    </>
  );
};

export default Home;
