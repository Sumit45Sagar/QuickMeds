
import { Link } from "react-router-dom";
import HeartIcon from "./HeartIcon";

const SmallProduct = ({ product }) => {
  return (
    <div className="w-80 mx-4 mb-10 p-4 bg-white dark:bg-emerald-900 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 relative">
      <div className="relative">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-40 object-cover rounded-md"
        />
        <HeartIcon product={product} />
      </div>

      <div className="pt-4">
        <Link to={`/product/${product._id}`}>
          <h2 className="flex justify-between items-center text-base font-semibold text-zinc-800 dark:text-white">
            <span className="truncate">{product.name}</span>
            <span className="bg-pink-100 text-pink-800 text-xs font-medium px-3 py-1 rounded-full dark:bg-pink-900 dark:text-pink-300">
              ₹{product.price}
            </span>
          </h2>
        </Link>
      </div>
    </div>
  );
};

export default SmallProduct;
