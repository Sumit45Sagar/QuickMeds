
import { useGetTopProductsQuery } from "../../redux/api/productApiSlice";
import Message from "../../components/Message";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import moment from "moment";
import {
  FaBox,
  FaClock,
  FaShoppingCart,
  FaStar,
  FaStore,
} from "react-icons/fa";

const ProductCarousel = () => {
  const { data: products, isLoading, error } = useGetTopProductsQuery();

  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    autoplay: true,
    autoplaySpeed: 3000,
  };

  return (
    <div className="mb-4 lg:block xl:block md:block">
    {/* <div className="mb-10 px-4"> */}
      {isLoading ? null : error ? (
        <Message variant="danger">
          {error?.data?.message || error.error}
        </Message>
      ) : (
        // <Slider {...settings} className="max-w-6xl mx-auto">
        <Slider {...settings} className="xl:w-[50rem]  lg:w-[50rem] md:w-[56rem] sm:w-[40rem] sm:block">
          {products.map(
            ({
              image,
              _id,
              name,
              price,
              description,
              brand,
              createdAt,
              numReviews,
              rating,
              quantity,
              countInStock,
            }) => (
              <div
                key={_id}
                className="bg-white dark:bg-zinc-900 rounded-xl shadow-md overflow-hidden"
              >
                <img
                  src={image}
                  alt={name}
                  className="w-full h-[28rem] object-cover rounded-t-xl"
                />

                <div className="p-6 md:flex md:justify-between md:gap-6">
                  {/* Left Side */}
                  <div className="flex-1">
                    <h2 className="text-2xl font-semibold text-zinc-900 dark:text-white">
                      {name}
                    </h2>
                    <p className="text-xl text-emerald-700 dark:text-emerald-300 font-bold my-2">
                      ₹{price}
                    </p>
                    <p className="text-zinc-600 dark:text-zinc-300 mt-4 max-w-lg">
                      {description.substring(0, 170)}...
                    </p>
                  </div>

                  {/* Right Side */}
                  <div className="mt-6 md:mt-0 flex flex-col md:flex-row gap-6">
                    <div>
                      <div className="flex items-center mb-3 text-sm text-zinc-700 dark:text-zinc-300">
                        <FaStore className="mr-2 text-emerald-600" /> Brand: {brand}
                      </div>
                      <div className="flex items-center mb-3 text-sm text-zinc-700 dark:text-zinc-300">
                        <FaClock className="mr-2 text-emerald-600" /> Added: {moment(createdAt).fromNow()}
                      </div>
                      <div className="flex items-center mb-3 text-sm text-zinc-700 dark:text-zinc-300">
                        <FaStar className="mr-2 text-yellow-500" /> Reviews: {numReviews}
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center mb-3 text-sm text-zinc-700 dark:text-zinc-300">
                        <FaStar className="mr-2 text-yellow-500" /> Ratings: {Math.round(rating)}
                      </div>
                      <div className="flex items-center mb-3 text-sm text-zinc-700 dark:text-zinc-300">
                        <FaShoppingCart className="mr-2 text-emerald-600" /> Quantity: {quantity}
                      </div>
                      <div className="flex items-center mb-3 text-sm text-zinc-700 dark:text-zinc-300">
                        <FaBox className="mr-2 text-emerald-600" /> In Stock: {countInStock}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )
          )}
        </Slider>
      )}
    </div>
  );
};

export default ProductCarousel;
