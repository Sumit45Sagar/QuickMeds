import { Link } from "react-router-dom";
import HeartIcon from "./HeartIcon";

const Product = ({ product }) => {
  return (
    <div className="w-full max-w-sm mx-auto p-4 rounded-xl shadow-md bg-emerald-900 hover:shadow-pink-500/30 transition duration-300 relative">
      <div className="relative">
        <img
          className="w-full h-44 object-cover rounded-lg"
          src={product.image}
          alt={product.name}
        />
        <div className="absolute top-2 right-2">
          <HeartIcon product={product} />
        </div>
      </div>

      <div className="mt-4">
        <Link to={`/product/${product._id}`}>
          <div className="flex justify-between items-center">
            <h2 className="text-white text-lg font-semibold truncate">{product.name}</h2>
            <span className="bg-pink-600 text-white text-sm font-medium px-3 py-1 rounded-full">
              ₹{product.price}
            </span>
          </div>
        </Link>
      </div>
    </div>
  );
};

export default Product;
