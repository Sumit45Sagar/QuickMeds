import { useState } from "react";
import { useNavigate, NavLink } from "react-router-dom";
import {
  useCreateProductMutation,
  useUploadProductImageMutation,
} from "../../redux/api/productApiSlice";
import { useFetchCategoriesQuery } from "../../redux/api/categoryApiSlice";
import { toast } from "react-toastify";
import AdminMenu from "./AdminMenu";

const ProductList = () => {
  const [image, setImage] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState("");
  const [quantity, setQuantity] = useState("");
  const [brand, setBrand] = useState("");
  const [stock, setStock] = useState(0);
  const [imageUrl, setImageUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const navigate = useNavigate();

  const [uploadProductImage] = useUploadProductImageMutation();
  const [createProduct] = useCreateProductMutation();
  const { data: categories } = useFetchCategoriesQuery();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const productData = new FormData();
      productData.append("image", image);
      productData.append("name", name);
      productData.append("description", description);
      productData.append("price", price);
      productData.append("category", category);
      productData.append("quantity", quantity);
      productData.append("brand", brand);
      productData.append("countInStock", stock);

      const { data } = await createProduct(productData);

      if (data.error) {
        toast.error("Product create failed. Try Again.");
      } else {
        toast.success(`${data.name} is created`);
        navigate("/");
      }
    } catch (error) {
      console.error(error);
      toast.error("Product create failed. Try Again.");
    }
  };

  const uploadFileHandler = async (e) => {
    const formData = new FormData();
    formData.append("image", e.target.files[0]);

    try {
      const res = await uploadProductImage(formData).unwrap();
      toast.success(res.message);
      setImage(res.image);
      setImageUrl(res.image);
    } catch (error) {
      toast.error(error?.data?.message || error.error);
    }
  };

  return (
    <>
      {/* <button className="top-20 right-5 bg-[#151515] p-2 fixed rounded-lg">
        <NavLink
          className="list-item py-2 px-3 block mb-5 hover:bg-[#2E2D2D] rounded-sm"
          to="/admin/allproductslist"
        >
          All Products
        </NavLink>
      </button> */}
      <button className="fixed top-20 right-5 bg-[#151515] p-3 rounded-lg z-50 shadow-lg">
  <NavLink
    to="/admin/allproductslist"
    className="block px-4 py-2 text-white bg-transparent hover:bg-[#2E2D2D] rounded-md transition duration-200 ease-in-out"
  >
    All Products
  </NavLink>
</button>

      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-3/4 w-full bg-zinc-900 rounded-xl shadow-lg overflow-hidden mx-auto">
            <div className="border-b border-zinc-800 p-6">
              <h1 className="text-2xl font-bold text-white">Create Product</h1>
            </div>

            <div className="p-6 space-y-8">
              {/* Image Upload Section */}
              <div className="space-y-4">
                <h2 className="text-lg font-medium text-zinc-300">
                  Product Image
                </h2>

                {imageUrl && (
                  <div className="bg-zinc-800 rounded-lg p-4 flex justify-center">
                    <img
                      src={imageUrl || "/placeholder.svg"}
                      alt="product"
                      className="max-h-[200px] object-contain rounded-md"
                    />
                  </div>
                )}

                <label
                  className="border-2 border-dashed border-zinc-700 hover:border-pink-500 transition-colors duration-200 
                              text-zinc-400 hover:text-white px-4 block w-full text-center rounded-lg cursor-pointer 
                              font-medium py-12 flex flex-col items-center justify-center gap-2"
                >
                  {image ? (
                    <>
                      <span className="text-pink-500">{image.name}</span>
                      <span className="text-sm">Click to change</span>
                    </>
                  ) : (
                    <>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-10 w-10 text-zinc-500"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                        />
                      </svg>
                      <span>Upload Image</span>
                      <span className="text-sm text-zinc-500">
                        Click to browse files
                      </span>
                    </>
                  )}

                  <input
                    type="file"
                    name="image"
                    accept="image/*"
                    onChange={uploadFileHandler}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Form Fields */}
              <div className="space-y-6">
                <h2 className="text-lg font-medium text-zinc-300">
                  Product Details
                </h2>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label
                      htmlFor="name"
                      className="text-sm font-medium text-zinc-400"
                    >
                      Name
                    </label>
                    <input
                      id="name"
                      type="text"
                      className="w-full p-3 rounded-lg bg-zinc-800 border border-zinc-700 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 text-white transition-all duration-200 outline-none"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Product name"
                    />
                  </div>

                  <div className="space-y-2">
                    <label
                      htmlFor="price"
                      className="text-sm font-medium text-zinc-400"
                    >
                      Price
                    </label>
                    <input
                      id="price"
                      type="number"
                      className="w-full p-3 rounded-lg bg-zinc-800 border border-zinc-700 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 text-white transition-all duration-200 outline-none"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      placeholder="0.00"
                    />
                  </div>

                  <div className="space-y-2">
                    <label
                      htmlFor="quantity"
                      className="text-sm font-medium text-zinc-400"
                    >
                      Quantity
                    </label>
                    <input
                      id="quantity"
                      type="number"
                      className="w-full p-3 rounded-lg bg-zinc-800 border border-zinc-700 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 text-white transition-all duration-200 outline-none"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      placeholder="0"
                    />
                  </div>

                  <div className="space-y-2">
                    <label
                      htmlFor="brand"
                      className="text-sm font-medium text-zinc-400"
                    >
                      Brand
                    </label>
                    <input
                      id="brand"
                      type="text"
                      className="w-full p-3 rounded-lg bg-zinc-800 border border-zinc-700 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 text-white transition-all duration-200 outline-none"
                      value={brand}
                      onChange={(e) => setBrand(e.target.value)}
                      placeholder="Brand name"
                    />
                  </div>

                  <div className="space-y-2">
                    <label
                      htmlFor="stock"
                      className="text-sm font-medium text-zinc-400"
                    >
                      Count In Stock
                    </label>
                    <input
                      id="stock"
                      type="number"
                      className="w-full p-3 rounded-lg bg-zinc-800 border border-zinc-700 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 text-white transition-all duration-200 outline-none"
                      value={stock}
                      onChange={(e) => setStock(e.target.value)}
                      placeholder="0"
                    />
                  </div>

                  <div className="space-y-2">
                    <label
                      htmlFor="category"
                      className="text-sm font-medium text-zinc-400"
                    >
                      Category
                    </label>
                    <select
                      id="category"
                      className="w-full p-3 rounded-lg bg-zinc-800 border border-zinc-700 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 text-white transition-all duration-200 outline-none"
                      onChange={(e) => setCategory(e.target.value)}
                      defaultValue=""
                    >
                      <option value="" disabled>
                        Choose Category
                      </option>
                      {categories?.map((c) => (
                        <option key={c._id} value={c._id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="description"
                    className="text-sm font-medium text-zinc-400"
                  >
                    Description
                  </label>
                  <textarea
                    id="description"
                    className="w-full p-3 rounded-lg bg-zinc-800 border border-zinc-700 focus:border-pink-500 focus:ring-1 focus:ring-pink-500 text-white transition-all duration-200 outline-none min-h-[120px]"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Product description"
                  ></textarea>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <button
                  onClick={handleSubmit}
                  disabled={isLoading}
                  className="py-3 px-8 rounded-lg text-base font-semibold bg-pink-600 hover:bg-pink-700 text-white transition-colors duration-200 flex items-center justify-center"
                >
                  {isLoading ? (
                    <>
                      <svg
                        className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Processing...
                    </>
                  ) : (
                    "Create Product"
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductList;
